/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Equality.Hashing.Course;
import Equality.Hashing.Enrollment;
import Equality.Hashing.Student;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.BeforeClass;
import Searching.Search;

/**
 *
 * @author Kiel Caralipio
 */
public class SearchTest {

    private static ArrayList<Student> students;
    private static ArrayList<Course> courses;
    private static ArrayList<Enrollment> enrollments;

    @BeforeClass

    public static void setUpClass() {

        Student s1 = new Student(1, "Software Development", "2/11/21", "Kiel", "kiel.tafesa.edu", 11111);
        Student s2 = new Student(2, "Web Development", "1/20/21", "Jack", "jack.tafesa.edu", 22222);
        students = new ArrayList<>(Arrays.asList(s1, s2));

        Course c1 = new Course(11, "5JAW", 250);
        Course c2 = new Course(22, "5CLP", 300);
        courses = new ArrayList<>(Arrays.asList(c1, c2));

        Enrollment e1 = new Enrollment("2/11/21", 70, "Semester 1");
        Enrollment e2 = new Enrollment("1/20/21", 100, "Semester 2");
        enrollments = new ArrayList<>(Arrays.asList(e1, e2));

    }

    @Test
    public void StudentBinary() {
        System.out.println("Student Binary Search");
        Student find = students.get(1);
        int expResult = 1;
        int result = Search.SBinarySearch(students, find);
    }

    @Test
    public void CourseBinary() {
        System.out.println("Course Binary Search");
        Course find = courses.get(1);
        int expResult = 1;
        int result = Search.CBinarySearch(courses, find);
    }

    @Test
    public void EnrollmentBinary() {
        System.out.println("Enrollment Binary Search");
        Enrollment find = enrollments.get(1);
        int expResult = 1;
        int result = Search.EBinarySearch(enrollments, find);
    }

    @Test
    public void StudentLinearSearch() {
        System.out.println("Student Linear Search");
        Student find = students.get(1);
        int expResult = 1;
        int result = Search.SBinarySearch(students, find);
    }

    @Test
    public void CourseLinearSearch() {
        System.out.println("Course Linear Search");
        Course find = courses.get(1);
        int expResult = 1;
        int result = Search.CBinarySearch(courses, find);
    }

    @Test
    public void EnrollmenLinearSearch() {
        System.out.println("Enrollment Linear Search");
        Enrollment find = enrollments.get(1);
        int expResult = 1;
        int result = Search.EBinarySearch(enrollments, find);
    }

}
