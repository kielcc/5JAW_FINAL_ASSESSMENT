
import Equality.Hashing.Course;
import Equality.Hashing.Enrollment;
import Equality.Hashing.Student;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import org.junit.Test;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Kiel Caralipio
 */
public class ClassTest {
    
    Student s1 = new Student(1, "Software Development", "2/11/21", "Kiel", "kiel.tafesa.edu", 11111);
    Student s2 = new Student(2, "Web Development", "1/20/21", "Jack", "jack.tafesa.edu", 22222);

    Course c1 = new Course(011, "5JAW", 250);
    Course c2 = new Course(022, "5CLP", 300);

    Enrollment e1 = new Enrollment("2/11/21", 70, "Semester 1");
    Enrollment e2 = new Enrollment("1/20/21", 100, "Semester 2");

  @Test
    public void TestEqualsTrue()
    {
        assertEquals(s1, s1);
        assertEquals(c1, c1);
        assertEquals(e1, e1);
    }
    @Test
        public void TestEqualsFalse()
    {
        assertNotEquals(s1, s2);
        assertNotEquals(c1, c2);
        assertNotEquals(e1, e2);
    }
    @Test
    public void TestHashCodeTrue()
    {
        assertEquals(s1.hashCode(), s1.hashCode());
        assertEquals(c1.hashCode(), c1.hashCode());
        assertEquals(e1.hashCode(), e1.hashCode());
    }
    @Test
    public void TestHashCodeFalse()
    {
        assertNotEquals(s1.hashCode(), s2.hashCode());
        assertNotEquals(c1.hashCode(), c2.hashCode());
        assertNotEquals(e1.hashCode(), e2.hashCode());
    }

}
