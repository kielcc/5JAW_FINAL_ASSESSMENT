
import Equality.Hashing.Course;
import Equality.Hashing.Enrollment;
import Equality.Hashing.Student;
import LinkedLists.Node;
import LinkedLists.SingleLinkedList;
import LinkedLists.DoublyLinkedList;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Kiel Caralipio
 */
public class LinkedListTest {

    Student s1 = new Student(1, "Software Development", "2/11/21", "Kiel", "kiel.tafesa.edu", 11111);
    Student s2 = new Student(2, "Web Development", "1/20/21", "Jack", "jack.tafesa.edu", 22222);

    Course c1 = new Course(011, "5JAW", 250);
    Course c2 = new Course(022, "5CLP", 300);

    Enrollment e1 = new Enrollment("2/11/21", 70, "Semester 1");
    Enrollment e2 = new Enrollment("1/20/21", 100, "Semester 2");

    SingleLinkedList<Student> StudentSinglieLinkedList;
    SingleLinkedList<Course> CourseSinglieLinkedList;
    SingleLinkedList<Enrollment> EnrollmentSinglieLinkedList;

    DoublyLinkedList<Student> StudentDoublyLinkedList;
    DoublyLinkedList<Course> CourseDoublyLinkedList;
    DoublyLinkedList<Enrollment> EnrollmentDoublyLinkedList;

    @Before
    public void init() {

        //Single Linked List
        StudentSinglieLinkedList = new SingleLinkedList<>();
        CourseSinglieLinkedList = new SingleLinkedList<>();
        EnrollmentSinglieLinkedList = new SingleLinkedList<>();

        //Doubly Linked List
        StudentDoublyLinkedList = new DoublyLinkedList<>();
        CourseDoublyLinkedList = new DoublyLinkedList<>();
        EnrollmentDoublyLinkedList = new DoublyLinkedList<>();
    }

//--------------------SINGLE LINKEDLIST TEST-----------------------------------------------------------
    @Test
    public void AddFirstSingleLinkedListTest() {
        System.out.println("SINGLE LINKED LIST || Add First Test");

        StudentSinglieLinkedList.addFirst(new Node(s1));
        StudentSinglieLinkedList.addFirst(new Node(s2));

        CourseSinglieLinkedList.addFirst(new Node(c1));
        CourseSinglieLinkedList.addFirst(new Node(c2));

        EnrollmentSinglieLinkedList.addFirst(new Node(e1));
        EnrollmentSinglieLinkedList.addFirst(new Node(e2));

        assertEquals(StudentSinglieLinkedList.getHead().getValue(), s2);
        assertEquals(CourseSinglieLinkedList.getHead().getValue(), c2);
        assertEquals(EnrollmentSinglieLinkedList.getHead().getValue(), e2);

    }

    @Test
    public void AddLastSingliLinkedListTest() {
        System.out.println("SINGLE LINKED LIST || Add Last Test");

        StudentSinglieLinkedList.addLast(new Node(s1));
        StudentSinglieLinkedList.addLast(new Node(s2));

        CourseSinglieLinkedList.addLast(new Node(c1));
        CourseSinglieLinkedList.addLast(new Node(c2));

        EnrollmentSinglieLinkedList.addLast(new Node(e1));
        EnrollmentSinglieLinkedList.addLast(new Node(e2));

        assertEquals(StudentSinglieLinkedList.getHead().getValue(), s1);
        assertEquals(CourseSinglieLinkedList.getHead().getValue(), c1);
        assertEquals(EnrollmentSinglieLinkedList.getHead().getValue(), e1);

    }

    @Test
    public void RemoveFirstSingleLinkedListTest() {
        System.out.println("SINGLE LINKED LIST || Remove First Test");

        StudentSinglieLinkedList.addLast(new Node(s1));
        StudentSinglieLinkedList.addLast(new Node(s2));

        CourseSinglieLinkedList.addLast(new Node(c1));
        CourseSinglieLinkedList.addLast(new Node(c2));

        EnrollmentSinglieLinkedList.addLast(new Node(e1));
        EnrollmentSinglieLinkedList.addLast(new Node(e2));

        StudentSinglieLinkedList.removeFirst();
        CourseSinglieLinkedList.removeFirst();
        EnrollmentSinglieLinkedList.removeFirst();

        assertEquals(StudentSinglieLinkedList.getHead().getValue(), s2);
        assertEquals(CourseSinglieLinkedList.getHead().getValue(), c2);
        assertEquals(EnrollmentSinglieLinkedList.getHead().getValue(), e2);

    }

    @Test
    public void RemoveLastSingleLinkedLisTest() {
        System.out.println("SINGLE LINKED LIST || Remove Last Test");

        StudentSinglieLinkedList.addLast(new Node(s1));
        StudentSinglieLinkedList.addLast(new Node(s2));

        CourseSinglieLinkedList.addLast(new Node(c1));
        CourseSinglieLinkedList.addLast(new Node(c2));

        EnrollmentSinglieLinkedList.addLast(new Node(e1));
        EnrollmentSinglieLinkedList.addLast(new Node(e2));

        StudentSinglieLinkedList.removeLast();
        CourseSinglieLinkedList.removeLast();
        EnrollmentSinglieLinkedList.removeLast();

        assertEquals(StudentSinglieLinkedList.getHead().getValue(), s1);
        assertEquals(CourseSinglieLinkedList.getHead().getValue(), c1);
        assertEquals(EnrollmentSinglieLinkedList.getHead().getValue(), e1);

    }

    @Test
    public void ContainsSingleLinkedListTest() {
        System.out.println("SINGLE LINKED LIST || Contains Test");

        StudentSinglieLinkedList.addLast(new Node(s1));
        StudentSinglieLinkedList.addLast(new Node(s2));

        CourseSinglieLinkedList.addLast(new Node(c1));
        CourseSinglieLinkedList.addLast(new Node(c2));

        EnrollmentSinglieLinkedList.addLast(new Node(e1));
        EnrollmentSinglieLinkedList.addLast(new Node(e2));

        assertEquals(StudentSinglieLinkedList.contains(s1), true);
        assertEquals(CourseSinglieLinkedList.contains(c1), true);
        assertEquals(EnrollmentSinglieLinkedList.contains(e1), true);

    }

    //--------------------DOUBLY LINKEDLIST TEST-----------------------------------------------------------
    @Test
    public void AddFirstDoublyLinkedListTest() {
        System.out.println("DOUBLY LINKED LIST || Add First Test");

        StudentDoublyLinkedList.addFirst(new Node(s1));
        StudentDoublyLinkedList.addFirst(new Node(s2));

        CourseDoublyLinkedList.addFirst(new Node(c1));
        CourseDoublyLinkedList.addFirst(new Node(c2));

        EnrollmentDoublyLinkedList.addFirst(new Node(e1));
        EnrollmentDoublyLinkedList.addFirst(new Node(e2));

        assertEquals(StudentDoublyLinkedList.getHead().getValue(), s2);
        assertEquals(CourseDoublyLinkedList.getHead().getValue(), c2);
        assertEquals(EnrollmentDoublyLinkedList.getHead().getValue(), e2);

    }

    @Test
    public void AddLastDoublyLinkedListTest() {
        System.out.println("DOUBLY LINKED LIST || Add Last Test");

        StudentDoublyLinkedList.addLast(new Node(s1));
        StudentDoublyLinkedList.addLast(new Node(s2));

        CourseDoublyLinkedList.addLast(new Node(c1));
        CourseDoublyLinkedList.addLast(new Node(c2));

        EnrollmentDoublyLinkedList.addLast(new Node(e1));
        EnrollmentDoublyLinkedList.addLast(new Node(e2));

        assertEquals(StudentDoublyLinkedList.getHead().getValue(), s1);
        assertEquals(CourseDoublyLinkedList.getHead().getValue(), c1);
        assertEquals(EnrollmentDoublyLinkedList.getHead().getValue(), e1);

    }

    @Test
    public void RemoveFirstDoublyLinkedListTest() {
        System.out.println("DOUBLY LINKED LIST || Remove First Test");

        StudentDoublyLinkedList.addLast(new Node(s1));
        StudentDoublyLinkedList.addLast(new Node(s2));

        CourseDoublyLinkedList.addLast(new Node(c1));
        CourseDoublyLinkedList.addLast(new Node(c2));

        EnrollmentDoublyLinkedList.addLast(new Node(e1));
        EnrollmentDoublyLinkedList.addLast(new Node(e2));

        StudentDoublyLinkedList.removeFirst();
        CourseDoublyLinkedList.removeFirst();
        EnrollmentDoublyLinkedList.removeFirst();

        assertEquals(StudentDoublyLinkedList.getHead().getValue(), s2);
        assertEquals(CourseDoublyLinkedList.getHead().getValue(), c2);
        assertEquals(EnrollmentDoublyLinkedList.getHead().getValue(), e2);

    }

    @Test
    public void RemoveLastDoublyLinkedListTest() {
        System.out.println("DOUBLY LINKED LIST || Remove Last Test");

        StudentDoublyLinkedList.addLast(new Node(s1));
        StudentDoublyLinkedList.addLast(new Node(s2));

        CourseDoublyLinkedList.addLast(new Node(c1));
        CourseDoublyLinkedList.addLast(new Node(c2));

        EnrollmentDoublyLinkedList.addLast(new Node(e1));
        EnrollmentDoublyLinkedList.addLast(new Node(e2));

        StudentDoublyLinkedList.removeLast();
        CourseDoublyLinkedList.removeLast();
        EnrollmentDoublyLinkedList.removeLast();

        assertEquals(StudentDoublyLinkedList.getHead().getValue(), s1);
        assertEquals(CourseDoublyLinkedList.getHead().getValue(), c1);
        assertEquals(EnrollmentDoublyLinkedList.getHead().getValue(), e1);

    }

    @Test
    public void ContainsDoublyLinkedListTest() {
        System.out.println("DOUBLY LINKED LIST || Contains Test");

        StudentDoublyLinkedList.addLast(new Node(s1));
        StudentDoublyLinkedList.addLast(new Node(s2));

        CourseDoublyLinkedList.addLast(new Node(c1));
        CourseDoublyLinkedList.addLast(new Node(c2));

        EnrollmentDoublyLinkedList.addLast(new Node(e1));
        EnrollmentDoublyLinkedList.addLast(new Node(e2));

        assertEquals(StudentDoublyLinkedList.contains(s1), true);
        assertEquals(CourseDoublyLinkedList.contains(c1), true);
        assertEquals(EnrollmentDoublyLinkedList.contains(e1), true);

    }

}
