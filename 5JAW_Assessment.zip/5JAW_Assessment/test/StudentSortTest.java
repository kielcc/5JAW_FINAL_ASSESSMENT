/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import Equality.Hashing.Student;
import Sorting.Sorting;
import java.util.ArrayList;
import java.util.List;
import static org.junit.Assert.assertArrayEquals;
import org.junit.Test;

/**
 *
 * @author Kiel Caralipio
 */
public class StudentSortTest {

    //Test Sort Student
    Student[] GroupAStudent = new Student[]{
        new Student(1, "Software Development", "2/11/21", "Kiel", "kiel.tafesa.edu", 11111),
        new Student(2, "Web Development", "1/20/21", "Jack", "jack.tafesa.edu", 22222),
        new Student(3, "Digital Media", "1/20/21", "Ryan", "ryan.tafesa.edu", 33333)
    };

    Student[] GroupBStudent = new Student[]{
        new Student(3, "Digital Media", "1/20/21", "Ryan", "ryan.tafesa.edu", 33333),
        new Student(2, "Web Development", "1/20/21", "Jack", "jack.tafesa.edu", 22222),
        new Student(1, "Software Development", "2/11/21", "Kiel", "kiel.tafesa.edu", 11111)
    };

    @Test
    public void StudentInsertSorting() {
        Sorting.InsertSort(GroupBStudent);
        assertArrayEquals(GroupAStudent, GroupBStudent);
    }

     @Test
    public void StudentSelectionSorting() {
        Sorting.SelectionSort(GroupBStudent);
        assertArrayEquals(GroupAStudent, GroupBStudent);
    }
    
    @Test
    public void StudentBubbleSorting() {
        Sorting.InsertSort(GroupBStudent);
        assertArrayEquals(GroupAStudent, GroupBStudent);
    }

}
