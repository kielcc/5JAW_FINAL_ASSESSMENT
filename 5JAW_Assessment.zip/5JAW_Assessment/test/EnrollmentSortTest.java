
import Equality.Hashing.Enrollment;
import Sorting.Sorting;
import static org.junit.Assert.assertArrayEquals;
import org.junit.Test;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Kiel Caralipio
 */
public class EnrollmentSortTest {

    //Test Sort Enrollment
    Enrollment[] GroupAEnrollment = new Enrollment[]{
        new Enrollment("2/11/21", 100, "Semester 1"),
        new Enrollment("1/20/21", 70, "Semester 2"),
        new Enrollment("2/01/21", 80, "Semester 1")
    };

    Enrollment[] GroupBEnrollment = new Enrollment[]{
        new Enrollment("1/20/21", 70, "Semester 2"),
        new Enrollment("2/01/21", 80, "Semester 1"),
        new Enrollment("2/11/21", 100, "Semester 1")

    };

    @Test
    public void CourseInsertSorting() {
        Sorting.InsertSort(GroupAEnrollment);
        assertArrayEquals(GroupBEnrollment, GroupAEnrollment);
    }

    @Test
    public void EnrollmentSelectionSorting() {
        Sorting.SelectionSort(GroupAEnrollment);
        assertArrayEquals(GroupBEnrollment, GroupAEnrollment);
    }

    @Test
    public void CourseBubbleSorting() {
        Sorting.InsertSort(GroupAEnrollment);
        assertArrayEquals(GroupBEnrollment, GroupAEnrollment);
    }

}
