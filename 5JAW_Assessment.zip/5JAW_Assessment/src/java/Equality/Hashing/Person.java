/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Equality.Hashing;

import java.util.Objects;

/**
 *
 * @author Kiel Caralipio
 */
public class Person {
    
    private String Name;
    private String Email;
    private int TelNum;
    
    
    //Constructor
    public Person(String Name, String Email, int TelNum) {
        this.Name = Name;
        this.Email = Email;
        this.TelNum = TelNum;
    }

    //Getters
    public String getName() {
        return Name;
    }

    public String getEmail() {
        return Email;
    }

    public int getTelNum() {
        return TelNum;
    }

    //Setters
    public void setName(String Name) {
        this.Name = Name;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public void setTelNum(int TelNum) {
        this.TelNum = TelNum;
    }

    //Hashcode
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + Objects.hashCode(this.Name);
        hash = 97 * hash + Objects.hashCode(this.Email);
        hash = 97 * hash + Objects.hashCode(this.TelNum);
        return hash;
    }

    //Equals
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Person other = (Person) obj;
        if (!Objects.equals(this.Name, other.Name)) {
            return false;
        }
        if (!Objects.equals(this.Email, other.Email)) {
            return false;
        }
        if (!Objects.equals(this.TelNum, other.TelNum)) {
            return false;
        }
        return true;
    }

    
    //ToString
    @Override
    public String toString() {
        return "Person{" + "Name=" + Name + ", Email=" + Email + ", TelNum=" + TelNum + '}';
    }
    
    
    
    
    
  

    
}
