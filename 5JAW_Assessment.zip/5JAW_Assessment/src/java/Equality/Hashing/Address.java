/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Equality.Hashing;

import java.util.Objects;

/**
 *
 * @author Kiel Caralipio
 */
public class Address {
    private int Number;
    private String Street;
    private String Suburb;
    private int PostCode;
    private String State;
    
    
    //Constructor
    public Address(int Number, String Street, String Suburb, int PostCode, String State) {
        this.Number = Number;
        this.Street = Street;
        this.Suburb = Suburb;
        this.PostCode = PostCode;
        this.State = State;
    }

    //Getters
    public int getNumber() {
        return Number;
    }

    public String getStreet() {
        return Street;
    }

    public String getSuburb() {
        return Suburb;
    }

    public int getPostCode() {
        return PostCode;
    }

    public String getState() {
        return State;
    }

    //Setters
    public void setNumber(int Number) {
        this.Number = Number;
    }

    public void setStreet(String Street) {
        this.Street = Street;
    }

    public void setSuberb(String Suburb) {
        this.Suburb = Suburb;
    }

    public void setPostCode(int PostCode) {
        this.PostCode = PostCode;
    }

    public void setState(String State) {
        this.State = State;
    }

    //HashCode
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + this.Number;
        hash = 59 * hash + Objects.hashCode(this.Street);
        hash = 59 * hash + Objects.hashCode(this.Suburb);
        hash = 59 * hash + this.PostCode;
        hash = 59 * hash + Objects.hashCode(this.State);
        return hash;
    }

    //Equals
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Address other = (Address) obj;
        if (this.Number != other.Number) {
            return false;
        }
        if (this.PostCode != other.PostCode) {
            return false;
        }
        if (!Objects.equals(this.Street, other.Street)) {
            return false;
        }
        if (!Objects.equals(this.Suburb, other.Suburb)) {
            return false;
        }
        if (!Objects.equals(this.State, other.State)) {
            return false;
        }
        return true;
    }

    //ToString
    @Override
    public String toString() {
        return "Address{" + "Number=" + Number + ", Street=" + Street + ", Suburb=" + Suburb + ", PostCode=" + PostCode + ", State=" + State + '}';
    }
    
    
    
}
