/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Equality.Hashing;

import java.util.Objects;

/**
 *
 * @author Kiel Caralipio
 */
public class Student extends Person  implements Comparable<Student>{
    public int StudentID;
    public String Program;
    public String DateRegistered;

    public Student(int StudentID, String Program, String DateRegistered, String Name, String Email, int TelNum) {
        super(Name, Email, TelNum);
        this.StudentID = StudentID;
        this.Program = Program;
        this.DateRegistered = DateRegistered;
    }

    public int getStudentID() {
        return StudentID;
    }

    public void setStudentID(int StudentID) {
        this.StudentID = StudentID;
    }

    public String getProgram() {
        return Program;
    }

    public void setProgram(String Program) {
        this.Program = Program;
    }

    public String getDateRegistered() {
        return DateRegistered;
    }

    public void setDateRegistered(String DateRegistered) {
        this.DateRegistered = DateRegistered;
    }
    

   
    
    //hash

    @Override   
    public int hashCode() {
        int hash = 3;
        hash = 61 * hash + this.StudentID;
        hash = 61 * hash + Objects.hashCode(this.Program);
        hash = 61 * hash + Objects.hashCode(this.DateRegistered);
        return hash;
    }

    //equals method
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Student other = (Student) obj;
        if (this.StudentID != other.StudentID) {
            return false;
        }
        if (!Objects.equals(this.Program, other.Program)) {
            return false;
        }
        if (!Objects.equals(this.DateRegistered, other.DateRegistered)) {
            return false;
        }
        return true;
    }
    

    
    //to string method
   

    @Override
    public String toString() {
        return "Student{" + "StudentID=" + StudentID + ", Program=" + Program + ", DateRegistered=" + DateRegistered + '}';
    }

    @Override
    public int compareTo(Student student) {
        return this.StudentID - student.StudentID;
    }

    
     
     

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
