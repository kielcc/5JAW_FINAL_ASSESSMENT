/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Equality.Hashing;

import java.util.Objects;

/**
 *
 * @author Kiel Caralipio
 */
public class Course implements Comparable<Course> {
    private int Code;
    private String CourseName;
    private double Cost;

    public Course(int Code, String CourseName, double Cost) {
        this.Code = Code;
        this.CourseName = CourseName;
        this.Cost = Cost;
    }

    //Getters and Setters
    public int getCode() {
        return Code;
    }

    public void setCode(int Code) {
        this.Code = Code;
    }

    public String getCourseName() {
        return CourseName;
    }

    public void setCourseName(String CourseName) {
        this.CourseName = CourseName;
    }

    public double getCost() {
        return Cost;
    }

    public void setCost(double Cost) {
        this.Cost = Cost;
    }

    //hashcode
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 71 * hash + this.Code;
        hash = 71 * hash + Objects.hashCode(this.CourseName);
        hash = 71 * hash + (int) (Double.doubleToLongBits(this.Cost) ^ (Double.doubleToLongBits(this.Cost) >>> 32));
        return hash;
    }

    //equals 
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Course other = (Course) obj;
        if (this.Code != other.Code) {
            return false;
        }
        if (Double.doubleToLongBits(this.Cost) != Double.doubleToLongBits(other.Cost)) {
            return false;
        }
        if (!Objects.equals(this.CourseName, other.CourseName)) {
            return false;
        }
        return true;
    }

    //ToString
    @Override
    public String toString() {
        return "Course{" + "Code=" + Code + ", CourseName=" + CourseName + ", Cost=" + Cost + '}';
    }

    @Override
    public int compareTo(Course course) {
       return this.Code - course.Code;
    }
    
    
    
    
    
}
