/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LinkedLists;

/**
 *
 * @author Kiel Caralipio
 */
public class DoublyLinkedList<T> {
    
    public int value;
    Node<T> head;
    Node<T> tail;
    Node<T> traverse;

    int count = 0;

    
    //Getters and Setters
    public Node<T> getHead() {
        return head;
    }

    public void setHead(Node<T> head) {
        this.head = head;
    }

    public Node<T> getTail() {
        return tail;
    }

    public void setTail(Node<T> tail) {
        this.tail = tail;
    }

    
    
    //AddFirst
    public void addFirst(Node<T> node) {
        Node<T> temp = head;
        head = node;
        head.next = temp;
        if (count == 0) {
            //if list is empty
            // the head and tail both point to the  new node
            tail = head;
            traverse = tail;
        } else {
            temp.previous = head;
        }
        count++;
    }

    //AddLast
    public void addLast(Node<T> node) {
        if (count == 0) //No Nodes
        {
            head = node;
        } else 
        {
            tail.next = node;
            node.previous = tail;
        }
        tail = node;
        traverse = tail;
        traverse.next = head;
        count++;
    }

    public void removeFirst() {
        if (count != 0) {
            head = head.next;
            count--;
            if (count == 0) {
                tail = null;
            } else {
                //now null
                head.previous = null;
            }
        }
    }

    public void removeLast() {
        if (count != 0) {
            if (count == 1) {
                head = null;
                tail = null;
            } else {
                tail.previous.next = null;
                tail = tail.previous;
            }
            count--;
        }
    }
    
    //Traverse Forward
    public Node<T>TraverseListForward(){
        if (traverse == tail)
        {
            traverse = head;
            return head;
        
        } else {
            
            traverse = traverse.next;
            return traverse;      
        }  
    }
    
     //Traverse Forward
    public Node<T>TraverseListReverse(){
        if (traverse == head)
        {
            traverse = tail;
            return tail;
        
        } else {
            
            traverse = traverse.previous;
            return traverse;      
        }  
    }
    
   
    public boolean contains(T item) {
        Node<T> current = head;
        while (current != null) {
            if (current.value.equals(item)) {
                return true;
            }
            current = current.next;
        }
        return false;
    }

}
