/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import Comparator.CourseSortingComparator;
import Comparator.StudentSortingComparator;
import Comparator.EnrollmentSortingComparator;
import Equality.Hashing.Student;
import org.junit.Test;
import java.util.ArrayList;
import java.util.List;
import Equality.Hashing.Course;
import Equality.Hashing.Enrollment;
import static org.junit.Assert.*;

/**
 *
 * @author Kiel Caralipio
 */
public class ComparatorTest {

    public ComparatorTest() {
    }

    @Test
    public void StudentComparator() {
        System.out.println("Compare Student");
        Student s1 = new Student(1, "Software Development", "2/11/21", "Kiel", "kiel.tafesa.edu", 11111);
        Student s2 = new Student(2, "Web Development", "1/20/21", "Jack", "jack.tafesa.edu", 22222);
        StudentSortingComparator instance = new StudentSortingComparator();
        int expResult = 0;
        int result = instance.compare(s1, s2);
    }

    @Test
    public void CourseComparator() {
        System.out.println("Compare Course");
        Course c1 = new Course(011, "5JAW", 250);
        Course c2 = new Course(022, "5CLP", 300);
        CourseSortingComparator instance = new CourseSortingComparator();
        int expResult = 0;
        int result = instance.compare(c1, c2);
    }

    @Test
    public void EnrollmentComparator() {
        System.out.println("Compare Enrollment");
        Enrollment  e1 = new Enrollment("2/11/21", 100, "Semester 1");
        Enrollment  e2 = new Enrollment("1/20/21", 70, "Semester 2");
        EnrollmentSortingComparator instance = new EnrollmentSortingComparator();
        int expResult = 0;
        int result = instance.compare(e1, e2);
    }

}
