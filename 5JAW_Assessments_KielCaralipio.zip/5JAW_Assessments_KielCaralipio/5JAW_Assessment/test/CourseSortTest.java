
import Equality.Hashing.Course;
import Sorting.Sorting;
import static org.junit.Assert.assertArrayEquals;
import org.junit.Test;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Kiel Caralipio
 */
public class CourseSortTest {

    //Test Sort Course 
    Course[] GroupACourse = new Course[]{
        new Course(1, "5JAW", 250),
        new Course(2, "5TSD", 350),
        new Course(3, "5CLP", 150)
    };

    Course[] GroupBCourse = new Course[]{
        new Course(3, "5CLP", 150),
        new Course(2, "5TSD", 350),
        new Course(1, "5JAW", 250)
    };

    @Test
    public void CourseInsertSorting() {
        Sorting.InsertSort(GroupBCourse);
        assertArrayEquals(GroupACourse, GroupBCourse);
    }

    @Test
    public void CourseSelectionSorting() {
        Sorting.SelectionSort(GroupBCourse);
        assertArrayEquals(GroupACourse, GroupBCourse);
    }

    @Test
    public void CourseBubbleSorting() {
        Sorting.InsertSort(GroupBCourse);
        assertArrayEquals(GroupACourse, GroupBCourse);
    }

}
