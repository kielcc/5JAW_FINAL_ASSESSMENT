/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Searching;

import Comparator.CourseSortingComparator;
import Comparator.EnrollmentSortingComparator;
import Comparator.StudentSortingComparator;
import Equality.Hashing.Course;
import Equality.Hashing.Enrollment;
import Equality.Hashing.Student;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Kiel Caralipio
 */
public class Search {
    
    //-------------BINARY SEARCH-------------------------

    public static int SBinarySearch(ArrayList<Student> li, Student find) {
        int max = li.size();
        int min = 0;
        while (min <= max) {
            int mid = (min + max) / 2;
            int studentCompare = new StudentSortingComparator().compare(li.get(mid), find);

            if (li.get(mid).equals(find)) {
                return mid;
            } else if (studentCompare > 0) {
                max = mid - 1;
            } else {
                min = mid;
            }
        }
        return -1;
    }
    

    public static int CBinarySearch(ArrayList<Course> li, Course find) {
        int max = li.size();
        int min = 0;
        while (min <= max) {
            int mid = (min + max) / 2;
            int courseCompare = new CourseSortingComparator().compare(li.get(mid), find);

            if (li.get(mid).equals(find)) {
                return mid;
            } else if (courseCompare > 0) {
                max = mid - 1;
            } else {
                min = mid;
            }
        }
        return -1;
    }

    public static int EBinarySearch(ArrayList<Enrollment> li, Enrollment find) {
        int max = li.size();
        int min = 0;
        while (min <= max) {
            int mid = (min + max) / 2;
            int enrollmentCompare = new EnrollmentSortingComparator().compare(li.get(mid), find);

            if (li.get(mid).equals(find)) {
                return mid;
            } else if (enrollmentCompare > 0) {
                max = mid - 1;
            } else {
                min = mid;
            }
        }
        return -1;
    }
    
    //-------------LINEAR SEARCH-------------------------
    
     public static int LinearSearch(Object[] List, Object findItem, int startListIndex)
    {
        int listIndex = -1;
        if (startListIndex > listIndex -1)
        {
            throw new ArrayIndexOutOfBoundsException();
        }
            for (int i = startListIndex; i < List.length; i++)
            {
                if (List[i].equals(findItem))
                {
                    listIndex = i;
                    break;
                }
            }
            return listIndex;
        }
     public static int search (Object[] List, Object findItem)
     {
         return LinearSearch(List, findItem, 0);
     }

}
