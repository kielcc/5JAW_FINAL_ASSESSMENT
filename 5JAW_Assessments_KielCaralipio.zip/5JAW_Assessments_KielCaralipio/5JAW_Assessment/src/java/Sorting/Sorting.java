/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sorting;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Kiel Caralipio
 */
public class Sorting {
    
//INSERT SORT
    public static void InsertSort(Comparable[] list) {
        for (int i = 1; i < list.length; ++i) {
            Comparable temp = list[i];
            int j = i - 1;
            while (j >= 0 && list[j].compareTo(temp) > 0) {
                list[j + 1] = list[j];
                j--;
            }
            list[j + 1] = temp;
        }
    }
//SELECT SORT
    public static void SelectionSort(Comparable[] list) {
        for (int i = 0; i < list.length - 1; i++) {
            int lastSorted = i;
            for (int j = i + 1; j < list.length; j++) {
                if (list[j].compareTo(list[lastSorted]) < 0) {
                    lastSorted = j;
                }
            }
            Comparable temp = list[lastSorted];
            list[lastSorted] = list[i];
            list[i] = temp;
        }
    }
//BUBBLE SORT
    public static void BubbleSort(Comparable[] list) {
        Comparable c;
        for (int j = 0; j <= list.length - 2; j++) {
            for (int i = 0; i <= list.length - 2; i++) {
                if (list[i].compareTo(list[i + 1]) > 0) {
                    c = list[i + 1];
                    list[i + 1] = list[i];
                    list[i] = c;
                }
            }
        }
    }

}
