/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Comparator;

import Equality.Hashing.Course;
import java.util.Comparator;
/**
 *
 * @author Kiel Caralipio
 */
public class CourseSortingComparator implements Comparator<Course> {
    
    @Override
    public int compare(Course c1, Course c2) {
        Double cost1 = c1.getCost();
        Double cost2 = c2.getCost();
        return cost1.compareTo(cost2);
    }
}
