/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Equality.Hashing;

import java.time.LocalDate;
import java.util.Objects;

/**
 *
 * @author Kiel Caralipio
 */
public class Enrollment implements Comparable<Enrollment>{
    private String DateEnrolled;
    private int Grade;
    private String Semester;
   

    public Enrollment(String DateEnrolled, int Grade, String Semester) {
        this.DateEnrolled = DateEnrolled;
        this.Grade = Grade;
        this.Semester = Semester;
    }

    public String getDateEnrolled() {
        return DateEnrolled;
    }

    public void setDateEnrolled(String DateEnrolled) {
        this.DateEnrolled = DateEnrolled;
    }

    public int getGrade() {
        return Grade;
    }

    public void setGrade(int Grade) {
        this.Grade = Grade;
    }

    public String getSemester() {
        return Semester;
    }

    public void setSemester(String Semester) {
        this.Semester = Semester;
    }

    //Hahcode
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.DateEnrolled);
        hash = 89 * hash + Objects.hashCode(this.Grade);
        hash = 89 * hash + Objects.hashCode(this.Semester);
        return hash;
    }
    
    //Equals
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Enrollment other = (Enrollment) obj;
        if (!Objects.equals(this.Grade, other.Grade)) {
            return false;
        }
        if (!Objects.equals(this.Semester, other.Semester)) {
            return false;
        }
        if (!Objects.equals(this.DateEnrolled, other.DateEnrolled)) {
            return false;
        }
        return true;
    }

    //toString
    @Override
    public String toString() {
        return "Enrollment{" + "DateEnrolled=" + DateEnrolled + ", Grade=" + Grade + ", Semester=" + Semester +'}';
    }

    @Override
    public int compareTo (Enrollment enrollment)
    {
        return this.Grade - enrollment.Grade;
    }
    
    
    
    
}
