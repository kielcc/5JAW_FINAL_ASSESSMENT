/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LinkedLists;

/**
 *
 * @author Kiel Caralipio
 */
public class SingleLinkedList<T> {

    Node<T> head;
    Node<T> tail;
    Node<T> traverse;

    int count = 0;

    public Node<T> getHead() {
        return head;
    }

    public void setHead(Node<T> head) {
        this.head = head;
    }

    public Node<T> getTail() {
        return tail;
    }

    public void setTail(Node<T> tail) {
        this.tail = tail;
    }

    public void addFirst(Node<T> node) {
        //Save off the head node so we dont loose it
        Node<T> temp = head;

        head = node;

        head.next = temp;
        count++;

        //if list was empty
        if (count == 1) {
            tail = head;
            traverse = tail;
        }
    }

    public void addLast(Node<T> node) {
        if (count == 0) // no nodes
        {
            head = node;
        } else {
            tail.next = node;
        }
        tail = node;
        traverse = tail;
        count++;
    }

    public void removeFirst() {
        if (count != 0) {

            head = head.next;
            count--;

            if (count == 0) {
                tail = null;
            }
        }
    }

    public void removeLast() {
        if (count != 0) {
            if (count == 1) {
                head = null;
                tail = null;
            } else {
                Node<T> current = head;
                while (current.next != tail) {
                    current = current.next;
                }
                current.next = null;
                tail = current;
            }
            count--;
        }

    }

    public boolean contains(T item) {
        Node<T> current = head;
        while (current != null) {
            if (current.value.equals(item)) {
                return true;
            }
            current = current.next;
        }
        return false;
    }
}
